HOTEL THE FIRST – BY HOTELIER ANANDS
Free static hotel website

Files:
- index.html: complete responsive website
- assets/hotel-building.jpg: uploaded hotel exterior image
- assets/reception.png: uploaded reception image

Preview:
Open index.html in a browser. Keep the assets folder next to index.html.

Publish for free:
1. Create/sign in to a GitHub account.
2. Create a new repository and upload index.html plus the entire assets folder.
3. In repository Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
4. Wait for GitHub Pages to publish the site; it will provide a public URL.

WhatsApp booking uses +91 86790 66004. Room prices are shown as supplied; availability and final terms should be confirmed directly with the hotel.
